
public class Demo {

	public static void main(String[] args) {
		int a=10,b=0,result;
		result=a/b;
		System.out.println("result="+result);;
	

	}

}
