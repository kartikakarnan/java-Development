
public class DemoException 
{
public static void main(String args[])
{
	int a[]= {2,3,4};
	a[5]=12;
	System.out.println(a[5]);
}
}
