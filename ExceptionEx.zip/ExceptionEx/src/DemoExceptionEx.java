
public class DemoExceptionEx {

	public static void main(String[] args) {
		try
		{
			int a[]= {2,3,4};
			a[5]=12;
			System.out.println(a[5]);
		}
		catch(Exception obj)
		{
			System.out.println(obj);
		}

	}

}
