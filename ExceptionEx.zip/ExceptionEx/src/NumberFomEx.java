import java.util.Scanner;
import java.util.InputMismatchException;
public class NumberFomEx {

	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		int a,b;
		String str=args[0];

		try
		{
			System.out.println("Enter the value");
			a=scan.nextInt();
			b=Integer.parseInt(str);
	
					
		}
		catch(InputMismatchException ae)
		{
			ae.printStackTrace();
			System.out.println(ae);
		}
		catch(NumberFormatException ie)
		{
			ie.printStackTrace();
		}
			finally
			{
				System.out.println("Exception caught/may not caught i will execute");
			}
	

	}

}
