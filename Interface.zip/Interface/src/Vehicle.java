interface vehicleone
{
	int speed=90;
	public void distance();
}
interface vehicletwo
{
	int distance=100;
	public void speed();
}
interface vehiclethree extends vehicleone, vehicletwo
{
	
}
public class Vehicle implements vehiclethree
{
	public void distance()
	{
		int distance=speed*100;
		System.out.println("distance travelled is: "+distance);
		
	}
	public void speed()
	{
		int speed=distance/100;
		System.out.println("speed: "+speed);
	}

}
class MultipleInheritanceUsingInterface
{
	public static void main(String args[])
	{
		Vehicle v=new Vehicle();
		System.out.println("vehicle");
		v.distance();
		v.speed();
	}
}
