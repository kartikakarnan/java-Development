interface interest
{
	public float ratecalc(float rate);
}
class Account implements interest
{
	int accid;
	String acname;
	float balance=5000f;
	Account()
	{
		accid=10001;
		acname="XXX";
		
	}
	public float ratecalc(float rate)
	{
		return balance =balance+(balance*(rate/100));
	}
	void disp()
	{
		System.out.println("Acoount Id="+accid);
		System.out.println("Acoount name="+acname);
		System.out.println("Acoount balance="+ratecalc(12));
	}
	public static void main(String args[])
	{
		Account a=new Account();
		a.disp();
	}
	

}
