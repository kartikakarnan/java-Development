
class EmpDetails {
	int did;
	String dname;
	void fun()
	{
		did=10;
		dname="sales";
	
	}

}
class Emp extends EmpDetails
{
	int eid;
	String ename;
	double sal;
	
	void accept()
	{
		fun();
		eid=100;
		ename="jhon";
		sal=12000;
	
	}
	void disp()
	{
		System.out.println("Dept id="+did);
		System.out.println("Dept name="+dname);
		System.out.println("Emp id="+eid);
		System.out.println("Emp name="+ename);
		System.out.println("Emp sal="+sal);
	}
	public static void main(String[] args)
	{
		Emp eobj=new Emp();
		eobj.accept();
		eobj.disp();
	}
		
	
	
}
