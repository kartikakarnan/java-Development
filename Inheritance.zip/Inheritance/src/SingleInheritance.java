
class SingleInheritance {
	void fun()
	{
		System.out.println("parent behaviour");
				
	}

}
class SingleInheritanceMain extends SingleInheritance
{
	void fun1()
	{
		System.out.println("child behaviour");
	}


	public static void main(String[] args)
	{
		SingleInheritanceMain obj=new SingleInheritanceMain();
		obj.fun();
		obj.fun1();
	}
}
