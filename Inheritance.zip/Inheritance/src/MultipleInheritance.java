
class MultipleInheritance {
	void methodx()
	{
		System.out.println("class x method");
		
	}	

}
class y extends MultipleInheritance
{
	void methody()
	{
		System.out.println("class y method");
	}
}
class MultipleInheritanceMain extends y
{
	void methodz()
	{
		System.out.println("class z method");
		
	}
	public static void main(String args)
	{
		MultipleInheritanceMain obj=new MultipleInheritanceMain();
		obj.methodx();
		obj.methody();
		obj.methodz();
	}
}