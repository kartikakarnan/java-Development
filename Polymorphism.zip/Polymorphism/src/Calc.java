
public class Calc {
	void sum(int a,int b)
	{
		System.out.println("sum two="+(a+b));
	}
	void sum(int a,int b,int c)
	{
		System.out.println("sum three="+(a+b+c));
	}
	void sum(float a,float b)
	{
		System.out.println("sum two="+(a+b));
	}
	public static void main(String args[])
	{
		Calc c=new Calc();
		c.sum(1.2f, 2.3f);
		c.sum(10, 20);
		c.sum(23, 45,65);
	}

}
