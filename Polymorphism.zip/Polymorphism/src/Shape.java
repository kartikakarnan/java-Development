
public class Shape {
	void area()
	{
		System.out.println("I am behaviour of shapes class");
						
	}

}
class Rect extends Shape
{
	int l=10,b=20;
	void area()
	{
		int ar=l*b;
		System.out.println("Area of rect="+ar);
	}
	public static void main(String args[])
	{
		Rect r=new Rect();
		r.area();
	}
}
