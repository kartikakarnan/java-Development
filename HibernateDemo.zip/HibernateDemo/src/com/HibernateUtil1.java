package com;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateUtil1 
{
	public static void main(String arg[])
	{
		try
		{
			Configuration config=new Configuration();
			config.configure("Course.cfg.xml");
			
			SessionFactory sessionFactory=config.buildSessionFactory();
			Session session=sessionFactory.openSession();
			
			Transaction tran=session.beginTransaction();
			com.Course course=new com.Course();
			course.setCourseId(1002);
			course.setCourseName("core java");
			course.setDurationInMonth(2);
			session.save(course);
			tran.commit();
			
			System.out.println("course Record Saved");
			
			
		}
		catch(Exception e)
		{
			System.out.println("Exception Arised:"+e);
		}
	}
}