import java.util.*;

public class ListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list1=new ArrayList();
		list1.add("sunil");
		list1.add("vinod");
		list1.add("rohit");
		list1.add(90);
		list1.add(10);
		Iterator itr=list.iterator();
		
	}

}
