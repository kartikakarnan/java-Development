import java.util.ArrayList;
public class ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list1=new ArrayList();
		list1.add("sunil");
		list1.add("vinod");
		list1.add("rohit");
		list1.add(90);
		list1.add(10);
		System.out.print("\nArrayList Element:"+list1);
		list1.add(2,"tarun");
		System.out.print("\nArrayList Element:"+list1);
		list1.remove(3);
		System.out.print("\nArrayList Element:"+list1);
		String content(String)list1.get(2);
		System.out.println("string from second location:"+content);
		int num(Integer)list1.get(3);
		System.out.println("integer from third location"+num);
		
		
		
				
		
		

	}

}
